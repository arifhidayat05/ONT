# ONT Recorder

Final project for Blockchain stream in Telkom Athon

ONT Recorder is an application that used to record every in and out ONT so that every availability ONT will be tracked. 

## How to use
1. Install GHC, cabal-install and haskell-language-server via [GHCup](https://www.haskell.org/ghcup/)
2. Open terminal, and change directory to this project
3. Run `$ cabal build`
4. After it successfully built, run this project with `$ cabal run`